package com.fakhrimf.moviesnshows.model

data class ErrorState(
    var error:Boolean,
    var errorMessage: String?
)