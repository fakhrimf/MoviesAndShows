package com.fakhrimf.moviesnshows.utils

import com.fakhrimf.moviesnshows.BuildConfig

const val backgroundFadeInDuration = 1000L
const val titleFadeInDuration = 1300L
const val pages = 2
const val API_KEY = BuildConfig.API
const val LOCALE_EN = "en"
const val MOVIE_KEY = "QYJTP9HALG"
const val SHOW_KEY = "nv3thhVjxJ"